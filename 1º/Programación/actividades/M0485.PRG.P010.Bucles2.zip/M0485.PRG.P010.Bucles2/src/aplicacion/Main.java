package aplicacion;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		System.out.println("Introduzca una valor límite:");
		Scanner peticion = new Scanner(System.in);
		int valorEntrado = peticion.nextInt();
		// Test01While.test(valorEntrado);
		// Test02DoWhile.test(valorEntrado);
		// Test03For.test(valorEntrado);
		Test04ForEach.test(valorEntrado);

	}

}
