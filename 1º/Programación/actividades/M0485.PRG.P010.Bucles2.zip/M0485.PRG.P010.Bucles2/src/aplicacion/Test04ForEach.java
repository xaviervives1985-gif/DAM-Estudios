package aplicacion;

public class Test04ForEach {

	public static void test(int limite) {
		// continue: Cancela la iteración en curso y vuelve
		// a validar la condicion de continuidad
		// break: Salimos del bucle.

		//int valores[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
		int valores[] = { 0, 1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
		for (int elemento : valores) {
			if (elemento != 0 && elemento % 6 == 0) {
				System.out.println("Salimos del bucle incondicionalmente por ser divisible entre 6");
				break;
			}
			if (elemento > limite) {
				System.out.println("Salimos del bucle incondicionalmente por superar el límite de elementos a tratar");
				break;
			}

			if (elemento % 2 != 0) // Se cumple si el resto es distinto a 0
			{
				System.out.println("Valor elemento: " + elemento + ". No es par.");
				continue;
			}
			System.out.println("Valor elemento: " + elemento);
		}
	}
}
