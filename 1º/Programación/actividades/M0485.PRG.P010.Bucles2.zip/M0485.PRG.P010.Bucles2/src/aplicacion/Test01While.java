package aplicacion;

public class Test01While {

	public static void test(int limite) {
		// continue: Cancela la iteración en curso y vuelve
		// a validar la condicion de continuidad
		// break: Salimos del bucle.

		int contador = 0;
		System.out.println("Inicio del bucle");

		while (contador <= limite) {
			
			if (contador != 0 && contador % 6 == 0) {
				System.out.println("Salimos del bucle incondicionalmente");
				break;
			}
			
			if (contador % 2 != 0) // Se cumple si el resto es distinto a 0
			{
				System.out.println("Valor contador: " + contador + ". No es par.");
				contador++;
				continue;
			}
			System.out.println("Valor contador: " + contador);
			contador++;

			
		}

		System.out.println("Fin del bucle");
	}

}
